"""AutoInsight backend package."""
